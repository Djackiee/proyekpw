<?php 
  session_start();
  // $conn = new mysqli('localhost', 'root', '', 'db_komik2');
  if(isset($_SESSION["items"])){
    $item = $_SESSION["items"];
    $item = json_decode($item,true);
    $id = $_SESSION["idus"];
    $id = json_decode($id,true);
  }
  else{
    $item = array();
  }

  
  $item = json_encode($item);
?>

<html>
<title>Checkout</title>
  <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript"
            src="https://app.sandbox.midtrans.com/snap/snap.js"
            data-client-key="SB-Mid-client-YCpKXgXpYUWVYu0W"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  </head>
  <body>

    <nav class="navbar navbar-light bg-light">
      <div class="container">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Item Yang Akan Dibeli</a>
        </div>
      </div>
    </nav>
    
    <main>
      <div class="container">
        <form id="payment-form" method="post" action="<?=site_url()?>/snap/finish">
          <input type="hidden" name="result_type" id="result-type" value="">
          <input type="hidden" name="result_data" id="result-data" value="">

          <?php 
            $item = json_decode($item,true);
            $total=0;
            foreach($item as $key => $value){
          ?>
            <div class="komik my-3">
              <div class="row">
                  <div class="col-3 col-md-3 col-lg-3 col-xl-1 d-flex justify-content-center align-items-center tempimg"><img src="../../gambar/<?=$value["locgambar"]?>" alt="" class="gambarkomik" width="50px"></div>
                  <div class="col-5 col-md-5 col-lg-5 col-xl-4 d-flex align-items-center">
                      <div class="judul">
                        <?=$value["judulkomik"]?>
                      </div> 
                  </div>
                  <div class="col-3 col-md-3 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                      Rp.<?=number_format($value["hargasatuan"],0,',','.')?>
                  </div>
                  <div class="col-9 col-md-6 col-lg-5 col-xl-1 mx-lg-3 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                    X<?=$value["qty"]?>
                  </div>
                  <div class="col-2 col-md-4 col-lg-4 col-xl-2 my-3 my-xl-0 d-flex justify-content-center align-items-center" id="subtotal">
                      Rp.<?=number_format($value["hargatotal"],0,',','.')?>
                  </div>
              </div>
            </div>
          <?php
            $total +=$value["hargatotal"];
            }
            $item = json_encode($item);
          ?>
          <input type="hidden" name="idus" id="idus" value="<?=$id[0]["id"]?>">
          <input type="hidden" name="email" id="email" value="<?=$id[0]["email"]?>">

          <div class="d-flex">
            <div class="ms-auto"></div>
            <div>
              <?=$total?>
            </div>
          </div>
          <a href="../../cart.php?id=<?=$id[0]["id"]?>" class="btn btn-danger" >Kembali ke cart</a>
          <!-- <a href="../../cart.php?id=<?=$id[0]["id"]?>" style="text-decoration: none;">
            <button class="btn btn-danger" >Kembali ke cart</button>
          </a> -->
          
          <button id="pay-button" class="btn btn-primary px-4" >Bayar sekarang</button>
          <div>
            <?= 
            site_url();
            ?>
          </div>
        </form>
        
        
      </div>
    </main>
    <script type="text/javascript">
  
    $('#pay-button').click(function (event) {
      event.preventDefault();
      $(this).attr("disabled", "disabled");
      var id = $("#idus").val();
      var email = $("#email").val();
      var item =JSON.stringify(<?=$item?>);;
    $.ajax({
      type: 'POST',
      url: '<?=site_url()?>/snap/token',
      url: "../controllers/Snap::createTransaction(<?=$params?>)->redirect_url;"
      data:{
        'idus':id,
        'email':email,
        'item':item
      },
      cache: false,

      success: function(data) {
        //location = data;

        console.log('token = '+data);
        
        var resultType = document.getElementById('result-type');
        var resultData = document.getElementById('result-data');

        function changeResult(type,data){
          $("#result-type").val(type);
          $("#result-data").val(JSON.stringify(data));
          //resultType.innerHTML = type;
          //resultData.innerHTML = JSON.stringify(data);
        }

        snap.pay(data, {
          
          onSuccess: function(result){
            changeResult('success', result);
            console.log(result.status_message);
            console.log(result);
            $("#payment-form").submit();
          },
          onPending: function(result){
            changeResult('pending', result);
            console.log(result.status_message);
            $("#payment-form").submit();
          },
          onError: function(result){
            changeResult('error', result);
            console.log(result.status_message);
            $("#payment-form").submit();
          }
        });
      }
    });
  });

  </script>


</body>
</html>
