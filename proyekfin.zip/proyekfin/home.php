<?php

// 	session_start();
// 	$page = $_SESSION["page"] ?? array(
// 		"no" => 1
// 	);



// // $url = 'https://www.bukukita.com/katalog/2-komik.html';

// // $curl = curl_init($url);

// // curl_exec($curl);

// // $ch = curl_init();

// // curl_setopt($ch, CURLOPT_URL, "https://www.bukukita.com/katalog/2-komik.html");

// // curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

// // $output = curl_exec($ch);

// // curl_close($ch);
// // // $data = json_decode($output);

// // echo "<pre>"; print_r($output); echo"</pre>";

// $curl = curl_init();


// $pagenow = $page["no"];


// $url = "https://www.bukukita.com/katalogbuku.php?page=".$pagenow."&masId=2&catId=&order=";

// $col1=$pagenow;
// $col2=$pagenow+1;
// $col3=$pagenow+2;

// curl_setopt($curl, CURLOPT_URL, $url);
// curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
// curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// // https://www.bukukita.com/babacms/displaybuku/90421.jpg

// $result = curl_exec($curl);

// preg_match_all("!https://www.bukukita.com/babacms/displaybuku/[^\s]*?.jpg!",$result, $matches);


// $images = array_values(array_unique($matches[0]));

// // print_r($images);

// // for($i = 0; $i < 17; $i++){
// // 	echo "<div style='float: left; margin-top: 10px' >";
// // 	echo "<img src = '$images[$i]'><br/>";
// // 	echo "</div>";
// // }

// curl_close($curl);

	require_once ("./controller/connection.php");

	$perpage = 16;
	$page = isset($_GET["halaman"]) ? (int)$_GET["halaman"] : 1;
	if ($page > 1){
		$awal = ($page * $perpage) - $perpage+1;
	}
	else{
		$awal = 1;
	}
	

	$id = $_GET["id"] ?? "";


	$akhir = $awal + 15;

	$stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik between ".$awal." and ".$akhir);
	$komik = $stmt->fetch_all(MYSQLI_ASSOC);

	
	$stmt = $conn->query("SELECT max(id_komik) FROM allkomik");
	$banyak = $stmt->fetch_assoc();
	$banyakint = (integer)$banyak["max(id_komik)"];

	$total = $banyakint / 16;
	$total=(integer)ceil($total);

	$stmt = $conn->query("SELECT * FROM allkomik order by id_komik desc");
	$newar = $stmt->fetch_all(MYSQLI_ASSOC);





?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>TOko Komik</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="style.css">
	
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container">
			<a class="navbar-brand logo" href="home.php?id=<?=$id?>">MeKomik</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-2 mb-2 mb-lg-0">
					<li class="nav-item">
					<a class="nav-link active" aria-current="page" href="home.php?id=<?=$id?>">Home</a>
					</li>
					<li class="nav-item">
					<a class="nav-link active" aria-current="page" href="catalog.php?id=<?=$id?>">Catalog</a>
					</li>
				</ul>
				<div class="search">
					<input class="form-control me-2" type="search" id="keyword" placeholder="Search" aria-label="Search">
					<button class="btn btn-outline-success" type="submit" onclick="cari()" value="<?=$id?>" id="btnsrc">
						search
					</button>
				</div>
				<a 
				<?php 
					if ($id == ""){
				?>
					href="login.php" 
				<?php 
					}
					else{
				?>
					href="cart.php?id=<?=$id?>" 
				<?php 
					}
				?>
				style="text-decoration: none;" class="ms-3" >
					<img src="./asset/keranjang.png" alt="">
				</a>
				<a 
				<?php 
					if ($id == ""){
				?>
					href="login.php" 
				<?php 
					}
					else{
				?>
					href="user.php?id=<?=$id?>" 
				<?php 
					}
				?>
				style="text-decoration: none;" class="ms-3" >
					<img src="./asset/user.png" alt="">
				</a>
			</div>
		</div>
	</nav>

	<main>
		

		<div class="container">

			<div id="carouselExampleIndicators" class="carousel slide mt-4" data-bs-ride="carousel">
				<div class="carousel-indicators">
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
					<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
				</div>
				<div class="carousel-inner">
					<div class="carousel-item active">
					<img src="./asset/car30per.png" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
					<img src="./asset/car20per.png" class="d-block w-100" alt="...">
					</div>
					<div class="carousel-item">
					<img src="./asset/carpoint.png" class="d-block w-100" alt="...">
					</div>
				</div>
				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Previous</span>
				</button>
				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden">Next</span>
				</button>
			</div>

			<div class="newarriv mt-4">
				<div class="judul tengah">
					<h2 class="bd">
						New Arrival
					</h2>
				</div>	
					<div class="row row-cols-2 row-cols-xl-4 g-4 mt-2">
					<?php 
						for ($i =0 ; $i<4 ; $i++){
					?>
						<div class="col">
							<div class="card h-100 bayang">
								<div class="gambarariv">
									<img src="./gambar/<?=$newar[$i]["dataimg"]?>" class="card-img-top" alt="...">
								</div>
								<div class="card-body">
									<h5 class="judul">
									<?php 
										if (strlen ($newar[$i]["judul"]) > 17){
											$jdl = $newar[$i]["judul"];
											$outjdl = substr($newar[$i]["judul"],0,13);
									?>
										<?=$outjdl?>...
									<?php 
										}
										else{
									?>
										<?=$newar[$i]["judul"]?>
									<?php 
										}
									?>

									</h5>
									<p class=" penulis"><?=$newar[$i]["penulis"]?></p>
									<p class=" harga"> Rp. <?=number_format($newar[$i]["harga"],0,',','.')?></p>
								</div>
								<div class="card-body">
									<a href="detail.php?id=<?=$id?>&idkom=<?=$newar[$i]["id_komik"]?>" style="text-decoration: none;">		
										<button type="button" class="btn btnbeli">Beli</button>
									</a>
								</div>
							</div>
						</div>
					<?php 
						}
					?>
				</div>
			</div>

			<div id="konten">
				<div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 g-4 mt-4">
				<?php
					foreach($komik as $key => $value){
						
				?>
							<div class="col">
								<div class="card h-100 bayang">
										
									<div class="gambar">
										<img src="./gambar/<?=$value["dataimg"]?>" class="card-img-top" alt="...">
									</div>
									<div class="card-body">
										<h5 class="judul">
										<?php 
											if (strlen ($value["judul"]) > 24){
												$jdl = $value["judul"];
												$outjdl = substr($value["judul"],0,20);
										?>
											<?=$outjdl?>...
										<?php 
											}
											else{
										?>
											<?=$value["judul"]?>
										<?php 
											}
										?>

										</h5>
										<p class=" penulis"><?=$value["penulis"]?></p>
										<p class=" harga"> Rp. <?=number_format($value["harga"],0,',','.')?></p>
									</div>
									<div class="card-body">
										<a href="detail.php?id=<?=$id?>&idkom=<?=$value["id_komik"]?>" style="text-decoration: none;">	
											<button type="button" class="btn btnbeli">Beli</button>
										</a>
									</div>
								</div>
							</div>
				<?php
					}
				?>
				</div>
				

				<div class="row align-items-end mt-4">
					<div class="col">
					</div>
					<div class="col tengah">
						<div aria-label="Page navigation example">
							<ul class="pagination">
								<li class="page-item">
									<a class="page-link" href="?id=<?=$id?>&halaman=
									<?php 
										if ($page > 1){
									?>
										<?=$page-1?>
									<?php 
										}
										else{
											
									?>
										<?=$page?>
									<?php 
										}
									?>
									" aria-label="Previous">
										<span aria-hidden="true">&laquo;</span>
									</a>
								</li>
								<?php 
									for($i=0; $i<$total; $i++){

								?>
								<li class="page-item"><a class="page-link" href="?id=<?=$id?>&halaman=<?=$i+1?>">
									<?=$i+1?>
								</a></li>
								<?php 
									}
								?>
								<li class="page-item">
									<a class="page-link" href="?id=<?=$id?>&halaman=
									<?php 
										if ($page < $total){
									?>
										<?=$page+1?>
									<?php 
										}
										else{
									?>
										<?=$page?>
									<?php 
										}
									?>
									" aria-label="Next">
										<span aria-hidden="true">&raquo;</span>
									</a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col">
					</div>
				</div>
			</div>
				
		</div>
	</main>

	
    <script>
        
        
        function cari(){
            let keyword = $("#keyword").val();
            let id = $("#btnsrc").val();
            $.ajax({
                type: "get",
                url: "./controller/loadkomik.php",
                data: {
                    'keyword' : keyword,
					'idus' : id
                },
                success: function(response){
                    $("#konten").html(response);
                }
            });
        }

    </script>


	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>

