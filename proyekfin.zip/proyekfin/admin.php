<?php 
    require_once("./controller/connection.php");

    
    $stmt = $conn->prepare("SELECT * FROM transaksi_midtrans");
    $stmt->execute();
    $pengguna = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $allkomik = $conn->query("SELECT * From allkomik order by id_komik asc")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MeKomik</title>
    <link rel="shortcut icon" href="asset/iconcomic.jpeg" type="image">
    <link rel="stylesheet" href="styleadmin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="admin.php">Data Komik</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="admindtrans.php">Data Transaksi</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>


    <main>
        <div class="container">
            <form action="" method="POST" enctype="multipart/form-data">
                judul : <br>
                <input type="text" name="judul" id="judul" placeholder="judul buku"><br>
                gambar : <br>
                <input type="file" name="foto" id="foto" > <br>
                harga : <br>
                <input type="number" name="harga" id="harga" placeholder="Harga"> <br>
                penulis : <br>
                <input type="text" name="penulis" id="penulis" placeholder="penulis"> <br>
                noisbn : <br>
                <input type="number" name="noisbn" id="noisbn" placeholder="noisbn"> <br>
                penerbit : <br>
                <input type="text" name="penerbit" id="penerbit" placeholder="penerbit"> <br>
                tanggal terbit : <br>
                <input type="date" name="tanggalterbit" id="tanggalterbit" > <br>
                jumlah halaman : <br>
                <input type="number" name="halaman" id="halaman" placeholder="Jumlah halaman"> <br>
                berat : <br>
                <input type="number" name="berat" id="berat" placeholder="berat"> <br>
                jenis cover : <br>
                <input type="text" name="cover" id="cover" placeholder="jenis cover"> <br>
                bahasa : <br>
                <input type="text" name="bahasa" id="bahasa" placeholder="bahasa"> <br>
                deskripsi : <br>
                <textarea name="deskripsi" id="deskripsi" cols="30" rows="10"></textarea> <br>
                stok : <br>
                <input type="text" name="stok" id="stok" placeholder="banyak stok"> <br>
                <input type="submit" name="simpan" value="Simpan produk">
            </form>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


    <?php 
        if(isset($_POST["simpan"])){
            $folder = "./gambar/";
            $name = $_FILES['foto']['name'];
            $sumber = $_FILES['foto']['tmp_name'];
            
            move_uploaded_file($sumber,$folder.$name);

            $judul = $_POST["judul"];
            $harga = $_POST["harga"];
            $penulis = $_POST["penulis"];
            $noisbn = $_POST["noisbn"];
            $penerbit = $_POST["penerbit"];
            $tanggalterbit = $_POST["tanggalterbit"];
            $halaman = $_POST["halaman"];
            $berat = $_POST["berat"];
            $cover = $_POST["cover"];
            $bahasa = $_POST["bahasa"];
            $deskripsi = $_POST["deskripsi"];
            $stok = $_POST["stok"];


            $stmt = $conn->prepare("INSERT INTO allkomik(dataimg, harga, judul, penulis, noisbn, penerbit, tanggal_terbit, jumlah_halaman, berat, jenis_cover, text_bahasa, deskripsi, stok) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sisssssiisssi",$name,$harga,$judul,$penulis,$noisbn,$penerbit,$tanggalterbit,$halaman,$berat,$cover,$bahasa,$deskripsi,$stok);
            $stmt->execute();
        }
    ?>
    <br>
<table border="1">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Harga</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>
                    Berat
                </th>
                <th>Stok</th>
                <th>Gambar</th>
                <th>Edit</th>
            </tr>
        </thead>
        <tbody>
            <?php
                    if ($allkomik != null) {
                        foreach ($allkomik as $key => $value) {
                            
                    ?>
                      <tr>
                        <td>
                             <div class="judul"> <?= $value["judul"] ?> </div>
                        </td>
                        
                        <td class="harga">
                            Rp. <?=number_format($value["harga"],0,',','.')?>
                        </td>
                        <td><?= $value["penulis"] ?></td>
                        <td><?= $value["penerbit"] ?></td>
                        <td class="berat"><?= $value["berat"] ?></td>
                        <td class= "stok"><?= $value["stok"] ?></td>
                        <td class="gambar">
                             <img src="./gambar/<?=$value["dataimg"]?>" class="card-img-top" alt="...">
                        </td>
                        <td>
                            <div class="edit">
                                <form action="#" method="get">
                                    <a href="editbook.php?id=<?= $value['id_komik']?>" class="btn btn-primary" name="edit">Edit</a>
                                </form>   
                            </div>
                        </td>
                      </tr>
                    <?php
                        }
                    }
                    
                    else{
                    ?>
                        <td colspan="5"> Tidak Ada Buku</td>
                        <?php
                    }
                    
            ?>
        </tbody>
    </table>

</body>
</html>