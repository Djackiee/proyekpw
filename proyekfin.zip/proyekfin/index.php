<?php

	require_once ("./controller/connection.php");


	if (isset($_COOKIE["id"])){
		$idco=$_COOKIE["id"];
		header("Location: home.php?id=".$idco);
	}
	else{
		header("Location: home.php");
	}

?>

