<?php 
    require_once("./controller/connection.php");

    $id = $_GET["id"] ?? "";


    
    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    $pengguna = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $idnow=0;
    foreach ($pengguna as $key => $value){
        if (hash("sha1",$value["id_user"]) == $id){
            $idnow = $value["id_user"];
        }
    }


    if (isset($_POST["keyword"])){
        $idcrt = $_POST["idcrt"];

        $result = $conn->query("DELETE FROM cart WHERE id_cart=$idcrt");

    }
    
    $stmt = $conn->prepare("SELECT * FROM cart WHERE id_user = ".$idnow);
    $stmt->execute();
    $keranjang = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $counter = 0;
    if ($keranjang !== null){
?>
<div class="p-3 mb-2 boxcarthead rounded-3 header">
    <div class="row">
        <div class="col-8 col-md-7 col-lg-6 col-xl-5 mx-md-0 mx-lg-3 mx-xl-1 my-2 text-center">komik</div>
        <div class="col-3 col-md-3 col-lg-2 col-xl-2 my-2 text-center">Harga satuan</div>
        <div class="col-8 col-md-7 col-lg-6 col-xl-1 mx-md-0 mx-lg-3 my-2 text-center">Qty</div>
        <div class="col-3 col-md-3 col-lg-2 col-xl-2 my-2 text-center">Harga total</div>
        <div class="col-9 col-md-1 col-lg-3 col-xl-1 my-2 text-center">Aksi</div>
    </div>
</div>
<?php 
        $hargatotal=0;
        foreach($keranjang as $key => $value){
            $counter++;
            $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$value["id_komik"]);
            $komik = $stmt->fetch_assoc();
?>
    <div class="p-3 mb-2 boxcart rounded-3 d-flex align-items-center" id="boxcrtid<?=$value['id_cart']?>">
        <div class="komik">
            <div class="row">
                <div class="col-3 col-md-3 col-lg-3 col-xl-1 d-flex justify-content-center align-items-center tempimg"><img src="./gambar/<?= $komik["dataimg"] ?>" alt="" class="gambar"></div>
                <div class="col-5 col-md-5 col-lg-5 col-xl-4 d-flex align-items-center">
                    <div class="judul">
                            <?= $komik["judul"] ?>
                    </div> 
                </div>
                <div class="col-3 col-md-3 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                    Rp.<?=number_format($komik["harga"],0,',','.')?>
                </div>
                <div class="col-9 col-md-6 col-lg-5 col-xl-1 mx-lg-3 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                    <div class="btn-group btn-light" role="group" aria-label="Basic outlined example">
                        <button class="btn btn-outline-primary" onclick="kurang(<?=$value['id_cart']?>)">-</button>
                        <input type="number" id="<?=$value["id_cart"]?>" value="<?= $value["qty"] ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                        <button class="btn btn-outline-primary" onclick="tambah(<?=$value['id_cart']?>)">+</button>
                    </div>
                </div>
                <div class="col-2 col-md-4 col-lg-4 col-xl-2 my-3 my-xl-0 d-flex justify-content-center align-items-center" id="subtotal">
                    Rp.<?=number_format($value["qty"]*$komik["harga"],0,',','.')?>
                </div>
                <div class="col-9 col-md-1 col-lg-1 col-xl-1 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                    <button class="btn btn-danger" onclick="hapus(<?=$value['id_cart']?>)">Delete</button>
                </div>
            </div>
        </div>
    </div>
<?php
        $hargatotal+=($value["qty"]*$komik["harga"]);
        }
?>
    <div class="total h-100" id="dettotal">
        <div class="row">
            <div class="col-0 col-md-6 col-lg-6 col-xl-6"></div>
            <div class="col-6 col-md-4 col-lg-4 col-xl-4">Poin yang dimiliki</div>
            <div class="col-6 col-md-2 col-lg-2 col-xl-2">: <?=$pointuser?> poin</div>
        </div>
        <div class="row mt-3">
            <div class="col-6 col-md-3 col-lg-3 col-xl-4 d-flex align-items-center"></div>
            <div class="col-6 col-md-1 col-lg-2 col-xl-3 d-flex justify-content-center align-items-center"></div>
            <div class="col-6 col-md-2 col-lg-2 col-xl-1 big d-flex justify-content-center align-items-center">Total:</div>
            <div class="col-6 col-md-4 col-lg-2 col-xl-2 big d-flex align-items-center">Rp.<?=number_format($hargatotal,0,',','.')?></div>
            <div class="col-6 col-md-2 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                <button class="btn btn-success px-4 bayar d-flex justify-content-center align-items-center">Bayar</button>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-8"></div>
            <div class="col-4 d-flex justify-content-center align-items-center">
                
            </div>
        </div>
    </div>
<?php
    }
    else{
?> 
    <div class="kosongchart">
        <img src="./asset/Keranjang.png" alt="" width="100" height="100">
        <p>Belum ada komik yang ditambahkan ke cart!</p>
        
    </div>
<?php
    }
?>
