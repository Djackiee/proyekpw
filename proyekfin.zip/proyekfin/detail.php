<?php 
    require_once("./controller/connection.php");

    $idkom = $_GET["idkom"];
    $id = $_GET["id"] ?? "";

    
    $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = '$idkom'");
    $komik = $stmt->fetch_assoc();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="styledet.css">
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@7.12.15/dist/sweetalert2.min.css'>
</head>
<body>
    
	<nav class="navbar navbar-expand-lg navbar-light">
		<div class="container">
			<a class="navbar-brand logo" href="home.php?id=<?=$id?>">MeKomik</a>
            <input type="hidden" id="idkom" value="<?=$idkom?>">
            <input type="hidden" id="idus" value="<?=$id?>">
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-2 mb-2 mb-lg-0">
					<li class="nav-item">
					<a class="nav-link active" aria-current="page" href="home.php?id=<?=$id?>">Home</a>
					</li>
					<li class="nav-item">
					<a class="nav-link active" aria-current="page" href="catalog.php?id=<?=$id?>">Catalog</a>
					</li>
				</ul>
                <div class="me-auto"></div>
                <div>
                    <a 
                    <?php 
                        if ($id == ""){
                    ?>
                        href="login.php" 
                    <?php 
                        }
                        else{
                    ?>
                        href="cart.php?id=<?=$id?>" 
                    <?php 
                        }
                    ?>
                    style="text-decoration: none;" class="ms-3" >
                        <img src="./asset/keranjang.png" alt="">
                    </a>
                    <a 
                    <?php 
                        if ($id == ""){
                    ?>
                        href="login.php" 
                    <?php 
                        }
                        else{
                    ?>
                        href="user.php?id=<?=$id?>" 
                    <?php 
                        }
                    ?>
                    style="text-decoration: none;" class="ms-3" >
                        <img src="./asset/user.png" alt="">
                    </a>
                </div>
			</div>
		</div>
	</nav>

    <main>
        <div class="container bgwhite">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-6 justify-self-center">
                    <div class="center">
                        <img src="./gambar/<?=$komik["dataimg"]?>" alt="" class="gambar">
                    </div>
                </div>

                <div class="col-12 col-lg-6">
                    <div class="boxdet">
                        <h3 class="judul mb-3">
                            <?=$komik["judul"]?>
                        </h3>

                        <h4 class="harga">
                            Rp <?=number_format($komik["harga"],0,',','.')?>
                        </h4>
                        <div class="infkom">
                            <div class="row">
                                <div class="col-6">
                                <p class="penulis">
                                    Penulis  
                                </p>
                                </div>
                                <div class="col-6">
                                : <?=$komik["penulis"]?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p> No ISBN  </p>
                                </div>
                                <div class="col-6">
                                    <?php 
                                        if ($komik["noisbn"] == 0){
                                    ?>
                                        : -
                                    <?php
                                        }
                                        else{
                                    ?>
                                        : <?=$komik["noisbn"]?>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p>
                                        Penerbit 
                                    </p>
                                </div>
                                <div class="col-6">
                                    : <?=$komik["penerbit"]?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p>
                                        Tanggal terbit  
                                    </p>
                                </div>
                                <div class="col-6">
                                    <?php 
                                        $tgl= date('F Y', strtotime($komik["tanggal_terbit"])); 
                                    ?>
                                    : <?=$tgl?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p>Jumlah Halaman</p>
                                </div>
                                <div class="col-6">
                                    <?php 
                                        if ($komik["jumlah_halaman"] == 0){
                                    ?>
                                        : -
                                    <?php
                                        }
                                        else{
                                    ?>
                                        : <?=$komik["jumlah_halaman"]?> gr
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p>Jenis Cover</p>
                                </div>
                                <div class="col-6">
                                    <?php 
                                        if ($komik["jenis_cover"] == ""){
                                    ?>
                                        : -
                                    <?php
                                        }
                                        else{
                                    ?>
                                        : <?=$komik["jenis_cover"]?>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <p>Text Bahasa</p>
                                </div>
                                <div class="col-6">
                                    <?php 
                                        if ($komik["text_bahasa"] == ""){
                                    ?>
                                        : -
                                    <?php
                                        }
                                        else{
                                    ?>
                                        : <?=$komik["text_bahasa"]?>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <a class="btn btn-primary" onclick="tambahcartbuy()">Buy</a>
                        <a class="btn btn-primary" id="tambahcart" onclick="tambahcart()">Add to chart</a>
                        
                    </div>

                </div>
                <div class="deskripsi">
                    <h3>Deskripsi</h3>
                    <?php 
                        if ($komik["deskripsi"] != ""){
                    ?>
                    <p>
                        <?=$komik["deskripsi"]?>
                    </p>
                    <?php 
                        }
                        else{
                    ?>
                    <p>
                        -
                    </p>
                    <?php 
                        }
                    ?>
                </div>
            </div>
        </div>

    </main>

    <script>
        
        function cari(){
            let keyword = $("#keyword").val();
            $.ajax({
                type: "get",
                url: "loadpost.php",
                data: {
                    'keyword' : keyword
                },
                success: function(response){
                    
                    $("#table-pos").html(response);
                }
            });
        }

        function tambahcart(){
            let idkomnow = $("#idkom").val();
            let idusnow = $("#idus").val();
            if (idusnow != ""){
                $.ajax({
                    type: "post",
                    url: "./controller/addcart.php",
                    data: {
                        'idkom' : idkomnow,
                        'idus' : idusnow
                    },
                })
                swal("Berhasil menambahkan Komik ke cart","","success");
            }
            else{
                window.location="login.php";
            }
            
        }

        function tambahcartbuy(){
            let idkomnow = $("#idkom").val();
            let idusnow = $("#idus").val();
            if (idusnow != ""){
                $.ajax({
                    type: "post",
                    url: "./controller/addcart.php",
                    data: {
                        'idkom' : idkomnow,
                        'idus' : idusnow
                    },
                })
                window.location="cart.php?id=<?=$id?>";
            }
            else{
                window.location="login.php";
            }
            
        }

    </script>
    
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    


</body>
</html>