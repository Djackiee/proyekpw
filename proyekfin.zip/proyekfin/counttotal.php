<?php 
    require_once("./controller/connection.php");

    $id = $_GET["id"] ?? "";
    
    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    $pengguna = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $idnow=0;
    $pointuser=0;
    foreach ($pengguna as $key => $value){
        if (hash("sha1",$value["id_user"]) == $id){
            $idnow = $value["id_user"];
            $pointuser = $value["point"];
        }
    }


    $stmt = $conn->prepare("SELECT * FROM cart WHERE id_user = ".$idnow);
    $stmt->execute();
    $keranjang = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $hargatotal = 0;
    foreach($keranjang as $key => $value){
        $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$value["id_komik"]);
        $komik = $stmt->fetch_assoc();
        $hargatotal += $value["qty"]*$komik["harga"];
    }

?>

<div class="row">
    <div class="col-0 col-md-6 col-lg-6 col-xl-6"></div>
    <div class="col-6 col-md-4 col-lg-4 col-xl-4">Poin yang dimiliki</div>
    <div class="col-6 col-md-2 col-lg-2 col-xl-2">: <?=$pointuser?> poin</div>
</div>
<div class="row mt-3">
    <div class="col-6 col-md-1 col-lg-3 col-xl-3 d-flex align-items-center"></div>
    <div class="col-6 col-md-1 col-lg-2 col-xl-3 d-flex justify-content-center align-items-center"></div>
    <div class="col-6 col-md-2 col-lg-2 col-xl-1 big d-flex justify-content-center align-items-center">Total:</div>
    <div class="col-6 col-md-4 col-lg-2 col-xl-2 big d-flex align-items-center">Rp.<?=number_format($hargatotal,0,',','.')?></div>
    <div class="col-6 col-md-2 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
        <form action="#" method="POST">
            <a href="./midtrans/index.php/snap" >
                <button class="btn btn-success px-3" name="checkout">Checkout</button> 
            </a>
        </form>
    </div>
</div>
<div class="row mt-3">
    <div class="col-8"></div>
    <div class="col-4 d-flex justify-content-center align-items-center">
        
    </div>
</div>

