<?php 
    require_once("./controller/connection.php");

    $id = $_GET["id"] ?? "";
    
    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    $pengguna = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $idnow=0;
    foreach ($pengguna as $key => $value){
        if (hash("sha1",$value["id_user"]) == $id){
            $idnow = $value["id_user"];
        }
    }

    $idcrt = $_POST["idcrt"];
    
    $stmt = $conn->query("SELECT * FROM cart WHERE id_cart = ".$idcrt);
    $keranjangnow = $stmt->fetch_assoc();

    $banyaknow = (integer)$keranjangnow["qty"];

    $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$keranjangnow["id_komik"]);
    $komiknow = $stmt->fetch_assoc();

    $banyakstok=(integer)$komiknow["stok"];


    $keyword = $_POST["keyword"];
    if ($keyword == "tambah"){
        if ($banyaknow < $banyakstok){
            $banyaknow++;
            $stmt = $conn->prepare("UPDATE cart SET qty=? WHERE id_cart = ?");
            $stmt->bind_param("ii",$banyaknow,$idcrt);
            $stmt->execute();
        }
    }
    else if ($keyword == "kurang"){
        if($banyaknow > 1){
            $banyaknow--;
            $stmt = $conn->prepare("UPDATE cart SET qty=? WHERE id_cart = ?");
            $stmt->bind_param("ii",$banyaknow,$idcrt);
            $stmt->execute();
        }
    }
    

    
    $stmt = $conn->query("SELECT * FROM cart WHERE id_cart = ".$idcrt);
    $value = $stmt->fetch_assoc();
    
    $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$keranjangnow["id_komik"]);
    $komik = $stmt->fetch_assoc();


?>
   <div class="komik">
        <div class="row">
            <div class="col-3 col-md-3 col-lg-3 col-xl-1 d-flex justify-content-center align-items-center tempimg"><img src="./gambar/<?= $komik["dataimg"] ?>" alt="" class="gambar"></div>
            <div class="col-5 col-md-5 col-lg-5 col-xl-4 d-flex align-items-center">
                <div class="judul">
                        <?= $komik["judul"] ?>
                </div> 
            </div>
            <div class="col-3 col-md-3 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                Rp.<?=number_format($komik["harga"],0,',','.')?>
            </div>
            <div class="col-9 col-md-6 col-lg-5 col-xl-1 mx-lg-3 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                <div class="btn-group btn-light" role="group" aria-label="Basic outlined example">
                    <button class="btn btn-outline-primary" onclick="kurang(<?=$value['id_cart']?>)">-</button>
                    <input type="number" id="<?=$value["id_cart"]?>" value="<?= $value["qty"] ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                    <button class="btn btn-outline-primary" onclick="tambah(<?=$value['id_cart']?>)">+</button>
                </div>
            </div>
            <div class="col-2 col-md-4 col-lg-4 col-xl-2 my-3 my-xl-0 d-flex justify-content-center align-items-center" id="subtotal">
                Rp.<?=number_format($value["qty"]*$komik["harga"],0,',','.')?>
            </div>
            <div class="col-9 col-md-1 col-lg-1 col-xl-1 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                <button class="btn btn-danger" onclick="hapus(<?=$value['id_cart']?>)">Delete</button>
            </div>
        </div>
    </div>