<?php 
    require_once("connection.php");


    if (isset($_POST["idkom"])){
        $iduser = $_POST["idus"];
        $idkomik = $_POST["idkom"];
        
        $stmt = $conn->query("SELECT max(id_user) FROM users");
        $banyak = $stmt->fetch_assoc();
        $banyakint = (integer)$banyak["max(id_user)"];
        for($i =1 ;$i <= $banyakint ; $i++){
            if (hash("sha1",$i) == $iduser){
                $idnorm = $i;
            }
        }

        $stmt = $conn->prepare("SELECT * FROM cart");
        $stmt->execute();
        $allcart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        $tambah = false;
        foreach($allcart as $key => $value){
            if ($value["id_komik"] == $idkomik && $value["id_user"] == $idnorm){
                $tambah = true;
                $idcart = $value["id_cart"];
                $qtynow = $value["qty"];
            }
        }

        if ($tambah == false){
            $satu = 1;
            $stmt = $conn->prepare("INSERT INTO CART(id_user, id_komik, qty) VALUES(?,?,?)");
            $stmt->bind_param("iii", $idnorm, $idkomik, $satu);
            $stmt->execute();
        }
        else{
            $satu = $qtynow+1;
            $stmt = $conn->prepare("UPDATE CART SET qty=? WHERE id_cart = ?");
            $stmt->bind_param("ii", $satu, $idcart);
            $result = $stmt->execute();
        }


    }

?>
