<?php 

    require_once("connection.php");

    if (isset($_GET["keyword"])){
        $stmt = $conn->prepare("SELECT * FROM allkomik where judul like ?");
        $id = $_GET['idus'];
        $keyword = "%".$_GET['keyword']."%";

        $stmt->bind_param("s", $keyword);
        $stmt->execute();
        $result = $stmt->get_result();

        $komik = $result->fetch_all(MYSQLI_ASSOC);
        
        $banyak=0;
        foreach($komik as $key => $value){
            $banyak++;
        }
        
        $total = $banyak / 16;
        $total=(integer)ceil($total);
    }
    else{
        $stmt = $conn->query("SELECT * FROM allkomik order by id_komik");
        $komik = $stmt->fetch_all(MYSQLI_ASSOC);
    }

    if($komik !== null){
?> 
    <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 g-4 mt-4">
<?php
        foreach($komik as $key => $value){
?>
                <div class="col">
                    <div class="card h-100 bayang">
                        <a href="detail.php?idkom=<?=$value["id_komik"]?>" style="text-decoration: none;">
                            <div class="gambar">
                                <img src="./gambar/<?=$value["dataimg"]?>" class="card-img-top" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="judul">
                                    <?php 
                                        if (strlen ($value["judul"]) > 24){
                                            $jdl = $value["judul"];
                                            $outjdl = substr($value["judul"],0,20);
                                    ?>
                                        <?=$outjdl?>...
                                    <?php 
                                        }
                                        else{
                                    ?>
                                        <?=$value["judul"]?>
                                    <?php 
                                        }
                                    ?>
                            
                                </h5>
                                <p class=" penulis"><?=$value["penulis"]?></p>
                                <p class=" harga"> Rp. <?=number_format($value["harga"],0,',','.')?></p>
                            </div>
                            <div class="card-body">
                                        <button type="button" class="btn btn-danger">Beli</button>
                            </div>
                        </a>    
                    </div>
                </div>
<?php 
        }
?>
    </div>
    <div class="row align-items-end mt-4">
        <div class="col">
        </div>
        <div class="col tengah">
            <div aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item">
                        <a class="page-link" href="?id=<?=$id?>&halaman=
                        <?php 
                            if ($page > 1){
                        ?>
                            <?=$page-1?>
                        <?php 
                            }
                            else{
                                
                        ?>
                            <?=$page?>
                        <?php 
                            }
                        ?>
                        " aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <?php 
                        for($i=0; $i<$total; $i++){

                    ?>
                    <li class="page-item"><a class="page-link" href="?id=<?=$id?>&halaman=<?=$i+1?>">
                        <?=$i+1?>
                    </a></li>
                    <?php 
                        }
                    ?>
                    <li class="page-item">
                        <a class="page-link" href="?id=<?=$id?>&halaman=
                        <?php 
                            if ($page < $total){
                        ?>
                            <?=$page+1?>
                        <?php 
                            }
                            else{
                        ?>
                            <?=$page?>
                        <?php 
                            }
                        ?>
                        " aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col">
        </div>
    </div>
<?php
    }
?>