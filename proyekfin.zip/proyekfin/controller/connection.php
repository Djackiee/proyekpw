<?php
session_start();
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'db_komik2';
$port = '3306';
$conn = new mysqli($host, $user, $password, $database);
$conn = new mysqli('localhost', 'root', '', 'db_komik2');
if ($conn->connect_errno) {
    die("gagal connect : " . $conn->connect_error);
}