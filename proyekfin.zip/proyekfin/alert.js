document.getElementById("tambahcart").addEventListener('click', function (){
    swal("Berhasil menambahkan Komik ke cart","","success");
});