<?php 
    require_once("./controller/connection.php");
    
    $id = $_GET["id"] ?? "";
    $idnow=0;

    $allitem = array();


    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    $pengguna = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $pointuser = 0;
    foreach ($pengguna as $key => $value){
        if (hash("sha1",$value["id_user"]) == $id){
            $idnow = $value["id_user"];
            $pointuser = $value["point"];
            $email = $value["email"];
        }
    }
    
    $stmt = $conn->prepare("SELECT * FROM cart WHERE id_user = ".$idnow);
    $stmt->execute();
    $keranjang = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $counter = 0;

    if (isset($_POST["checkout"])){
        
        $stmt = $conn->prepare("SELECT * FROM cart WHERE id_user = ".$idnow);
        $stmt->execute();
        $keranjang = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        foreach($keranjang as $key => $value){
            $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$value["id_komik"]);
            $komik = $stmt->fetch_assoc();
            $item = array(
                "locgambar" => $komik["dataimg"],
                "judulkomik" => $komik["judul"],
                "qty" => $value["qty"],
                "hargasatuan" => $komik["harga"],
                "hargatotal" => $komik["harga"]*$value["qty"]
            );
            array_push($allitem,$item);
        }
        
        header("Location: ./midtrans/index.php/snap");
        $allitem = json_encode($allitem);
        $_SESSION["items"] = $allitem;
        $nowus=array();
        $dataus = array(
            "id" => $id,
            "email" => $email,
        );
        array_push($nowus,$dataus);
        $nowus = json_encode($nowus);
        $_SESSION["idus"] = $nowus;

    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript"
            src="https://app.sandbox.midtrans.com/snap/snap.js"
            data-client-key="SB-Mid-client-YCpKXgXpYUWVYu0W"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <link rel="stylesheet" href="cart.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <div class="mekom">
                
                <a class="navbar-brand logo" href="home.php?id=<?=$id?>">MeKomik</a>
                <div class="batas">|</div>
                <div class="nama">Cart</div>
            </div>
        </div>
    </nav>
    <main>
        <div class="container">
            <div class="mt-4">
                <div id="allcart">
            <?php 
                if ($keranjang != null){
                    
            ?>
            
                <div class="p-3 mb-2 boxcarthead rounded-3 header">
                    <div class="row">
                        <div class="col-8 col-md-7 col-lg-6 col-xl-5 mx-md-0 mx-lg-3 mx-xl-1 my-2 text-center">komik</div>
                        <div class="col-3 col-md-3 col-lg-2 col-xl-2 my-2 text-center">Harga satuan</div>
                        <div class="col-8 col-md-7 col-lg-6 col-xl-1 mx-md-0 mx-lg-3 my-2 text-center">Qty</div>
                        <div class="col-3 col-md-3 col-lg-2 col-xl-2 my-2 text-center">Harga total</div>
                        <div class="col-9 col-md-1 col-lg-3 col-xl-1 my-2 text-center">Aksi</div>
                    </div>
                </div>
                <?php 
                        $hargatotal=0;
                        foreach($keranjang as $key => $value){
                            $counter++;
                            $stmt = $conn->query("SELECT * FROM allkomik WHERE id_komik = ".$value["id_komik"]);
                            $komik = $stmt->fetch_assoc();
                ?>
                    <div class="p-3 mb-2 boxcart rounded-3 d-flex align-items-center" id="boxcrtid<?=$value['id_cart']?>">
                        <div class="komik">
                            <div class="row">
                                <div class="col-3 col-md-3 col-lg-3 col-xl-1 d-flex justify-content-center align-items-center tempimg"><img src="./gambar/<?= $komik["dataimg"] ?>" alt="" class="gambar"></div>
                                <div class="col-5 col-md-5 col-lg-5 col-xl-4 d-flex align-items-center">
                                    <div class="judul">
                                            <?= $komik["judul"] ?>
                                    </div> 
                                </div>
                                <div class="col-3 col-md-3 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                                    Rp.<?=number_format($komik["harga"],0,',','.')?>
                                </div>
                                <div class="col-9 col-md-6 col-lg-5 col-xl-1 mx-lg-3 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                                    <div class="btn-group btn-light" role="group" aria-label="Basic outlined example">
                                        <button class="btn btn-outline-primary" onclick="kurang(<?=$value['id_cart']?>)">-</button>
                                        <input type="number" id="<?=$value["id_cart"]?>" value="<?= $value["qty"] ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                        <button class="btn btn-outline-primary" onclick="tambah(<?=$value['id_cart']?>)">+</button>
                                    </div>
                                </div>
                                <div class="col-2 col-md-4 col-lg-4 col-xl-2 my-3 my-xl-0 d-flex justify-content-center align-items-center" id="subtotal">
                                    Rp.<?=number_format($value["qty"]*$komik["harga"],0,',','.')?>
                                </div>
                                <div class="col-9 col-md-1 col-lg-1 col-xl-1 my-3 my-xl-0 d-flex justify-content-center align-items-center">
                                    <button class="btn btn-danger" onclick="hapus(<?=$value['id_cart']?>)">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                        $hargatotal+=($value["qty"]*$komik["harga"]);
                        }
                ?>
                    <div class="total h-100" id="dettotal">
                        <div class="row">
                            <div class="col-0 col-md-6 col-lg-6 col-xl-6"></div>
                            <div class="col-6 col-md-4 col-lg-4 col-xl-4">Poin yang dimiliki</div>
                            <div class="col-6 col-md-2 col-lg-2 col-xl-2">: <?=$pointuser?> poin</div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-6 col-md-1 col-lg-3 col-xl-3 d-flex align-items-center"></div>
                            <div class="col-6 col-md-1 col-lg-2 col-xl-3 d-flex justify-content-center align-items-center"></div>
                            <div class="col-6 col-md-2 col-lg-2 col-xl-1 big d-flex justify-content-center align-items-center">Total:</div>
                            <div class="col-6 col-md-4 col-lg-2 col-xl-2 big d-flex align-items-center">Rp.<?=number_format($hargatotal,0,',','.')?></div>
                            <div class="col-6 col-md-2 col-lg-2 col-xl-2 d-flex justify-content-center align-items-center">
                                <form action="#" method="POST">
                                    <!-- <a href="./midtrans/index.php/snap" > -->
                                        <button class="btn btn-success px-3" name="checkout">Checkout</button> 
                                    <!-- </a> -->
                                </form>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-8"></div>
                            <div class="col-4 d-flex justify-content-center align-items-center">
                                
                            </div>
                        </div>
                    </div>
                <?php
                    }
                    else{
                ?> 
                    <div class="kosongchart">
                        <img src="./asset/Keranjang.png" alt="" width="100" height="100">
                        <p>Belum ada komik yang ditambahkan ke cart!</p>
                    </div>
                <?php
                    }
                ?>
                </div>
            </div>
        </div>
    </main>

    <script>

        function cekboxcek(id){
            let typecb = "satu";
            let thecb = $("#cb"+id);
            let iscentang = "tidak";
            if (thecb.prop("checked") == true){
                iscentang = "ya";
            }
            else if (thecb.prop("checked") == false){
                iscentang = "tidak";
            }
            $.ajax({
                type: "post",
                url: "counttotal.php?id=<?=$id?>",
                data: {
                    'idcrt' : id,
                    'typecb' : typecb,
                    'iscentang' : iscentang
                },
                success: function(response){
                    $("boxcrtid"+id).html(response);
                }
            });
        }

        function updatetotal(){
            $.ajax({
                type: "post",
                url: "counttotal.php?id=<?=$id?>",
                success: function(response){
                    $("#dettotal").html(response);
                }
            });
        }


        function tambah(id){
            let idcrt = id;
            let keyword = "tambah";
            $.ajax({
                type: "post",
                url: "qtyupdown.php?id=<?=$id?>",
                data: {
                    'keyword' : keyword,
                    'idcrt' : idcrt
                },
                success: function(response){
                    $("#boxcrtid"+idcrt).html(response);
                    updatetotal();
                }
            });
        }

        function kurang(id){
            let idcrt = id;
            let keyword = "kurang";
            $.ajax({
                type: "post",
                url: "qtyupdown.php?id=<?=$id?>",
                data: {
                    'keyword' : keyword,
                    'idcrt' : idcrt
                },
                success: function(response){
                    $("#boxcrtid"+idcrt).html(response);
                    updatetotal();
                }
            });
        }

        function hapus(id){
            let idcrt = id;
            let keyword = "delete";
            $.ajax({
                type: "post",
                url: "deletecart.php?id=<?=$id?>",
                data: {
                    'keyword' : keyword,
                    'idcrt' : idcrt
                },
                success: function(response){
                    $("#allcart").html(response);
                    updatetotal();
                }
            });
        }
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>