<?php 
    require_once("./controller/connection.php");
    

    
    $stmt = $conn->prepare("SELECT * FROM users");
    $stmt->execute();
    $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $id = $_GET["id"] ?? "";
    
    $action = $_REQUEST["action"];
    if($action == "regis"){
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];

        if ($username == ""){
            $_SESSION["message"] = "Harap menginputkan nama terlebih dahulu!";
            header("Location: register.php");
        }
        else if ($email == ""){
            $_SESSION["message"] = "Harap menginputkan email terlebih dahulu!";
            header("Location: register.php");
        }
        else if ($password == ""){
            $_SESSION["message"] = "Harap menginputkan password terlebih dahulu!";
            header("Location: register.php");
        }
        else if ($password != $cpassword){
            $_SESSION["message"] = "Confirm password berbeda, harap inputkan ulang!";
            header("Location: register.php");
        }
        else{
            $validusername = true;
            $validemail = true;
            foreach ($users as $key => $value){
                if($value["username"]== $username){
                    $validusername = false;
                    if($value["email"]== $email){
                        $validemail = false;
                    }
                }
            }

            if ($validemail == false){
                $_SESSION["message"] = "Akun anda sudah terdaftar!";
                header("Location: register.php");
            }
            else if ($validusername == false){
                $_SESSION["message"] = "Username telah digunakan, silahkan inputkan username yang berbeda!";
                header("Location: register.php");
            }
            else if ($validusername==true && $validemail==true){
                $encryptpass = hash("sha1",$password);
                $point = 0;
                $stmt = $conn->prepare("INSERT INTO users(username, email, password, point) VALUES(?,?,?,?)");
                $stmt->bind_param("sssi", $username, $email, $encryptpass, $point);
                $stmt->execute();
                $_SESSION["message"] = "Registrasi berhasil!";
                header("Location: login.php");
            }
        }

    }
    else if ($action == "login"){
        $username = $_POST["username"];
        $password = $_POST["password"];

        if ($username == "" || $password == ""){
            $_SESSION["message"] = "Silahkan inputkan yang kosong";
            header("Location: login.php");
        }
        else{
            $ada = false;
            foreach ($users as $key => $value){
                if($value["username"]== $username || $value["email"] == $username){
                    $ada = true;
                    $uspass = $value["password"];
                    $id = hash("sha1",$value["id_user"]);
                }
            }
            if ($ada == true){
                if ($uspass == hash("sha1",$password)){
                    setcookie('id',$id, time() + 5*60*60);
                    header("Location: index.php?id=".$_COOKIE["id"]);
                }
                else{
                    $_SESSION["message"] = "Password Salah!!";
                    header("Location: login.php");
                }
            }
            else{
                $_SESSION["message"] = "User tidak terdaftar, silahkan registrasi terlebih dahulu!";
                header("Location: login.php");
            }
        }
    }
    else if($action == "logout"){
        setcookie('id',$id, time() - 5*60*60);
        header("Location: home.php");
    }
?>