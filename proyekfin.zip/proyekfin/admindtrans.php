<?php 
    require_once("./controller/connection.php");

    
    $stmt = $conn->prepare("SELECT * FROM transaksi_midtrans order by id_trans desc");
    $stmt->execute();
    $transaksi = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="admin.php">Data Komik</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="admindtrans.php">Data Transaksi</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>


    <main>
        <div class="container">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Order id</th>
                        <th>User id</th>
                        <th>Total tagihan</th>
                        <th>Metode pembayaran</th>
                        <th>Waktu transaksi</th>
                        <th>Bank</th>
                        <th>VA number</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        foreach($transaksi as $key => $value){
                            $tanggaltrans = $value["transaction_time"];
                            
                            $tanggaltrans = date("Y-m-d H:i:s", strtotime($tanggaltrans));
                    ?>
                    <tr>
                        <td><?=$value["order_id"]?></td>
                        <td><?=$value["payment_type"]?></td>
                        <td class="text-end">
                            <?=number_format($value["gross_amount"],0,',','.')?>
                        </td>
                        <td><?=$value["payment_type"]?></td>
                        <td>
                            <?=$tanggaltrans?>
                        </td>
                        <td><?=$value["bank"]?></td>
                        <td><?=$value["va_numbers"]?></td>
                        <td>
                            <?php 
                                if ($value["status_code"] == 200){
                            ?>
                                <span class="badge rounded-pill bg-success text-dark">Lunas</span>
                            <?php 
                                }
                                else{
                            ?>
                                <span class="badge rounded-pill bg-warning text-dark">Pending</span>
                            <?php 
                                }
                            ?>
                    
                        </td>
                    </tr>
                    <?php 
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


    <?php 
        if(isset($_POST["simpan"])){
            $folder = "./gambar/";
            $name = $_FILES['foto']['name'];
            $sumber = $_FILES['foto']['tmp_name'];
            
            move_uploaded_file($sumber,$folder.$name);

            $judul = $_POST["judul"];
            $harga = $_POST["harga"];
            $penulis = $_POST["penulis"];
            $noisbn = $_POST["noisbn"];
            $penerbit = $_POST["penerbit"];
            $tanggalterbit = $_POST["tanggalterbit"];
            $halaman = $_POST["halaman"];
            $berat = $_POST["berat"];
            $cover = $_POST["cover"];
            $bahasa = $_POST["bahasa"];
            $deskripsi = $_POST["deskripsi"];
            $stok = $_POST["stok"];


            $stmt = $conn->prepare("INSERT INTO allkomik(dataimg, harga, judul, penulis, noisbn, penerbit, tanggal_terbit, jumlah_halaman, berat, jenis_cover, text_bahasa, deskripsi, stok) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sisssssiisssi",$name,$harga,$judul,$penulis,$noisbn,$penerbit,$tanggalterbit,$halaman,$berat,$cover,$bahasa,$deskripsi,$stok);
            $stmt->execute();
        }
    ?>
</body>
</html>